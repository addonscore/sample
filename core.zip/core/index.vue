<template>
  <VRow>
    <VCol
      cols="12"
      md="12"
    >
      <VCard title="Welcome">
        <VCardText>
          Core 
        </VCardText>
      </VCard>
    </VCol>
  
  </VRow>
</template>

<route lang="yaml">
  meta:
    action: manage
    subject: Client
  </route>
    
  